package com.mzj.springframework.aop._03_condition;

public interface SingASong {
  void sing(String SongName, String SongContext);
}
